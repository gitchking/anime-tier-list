import { type User, type InsertUser, type TierList, type InsertTierList, type Todo, type InsertTodo } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Tier list methods
  getTierList(id: number): Promise<TierList | undefined>;
  getTierListsByUserId(userId: number): Promise<TierList[]>;
  createTierList(tierList: InsertTierList): Promise<TierList>;
  updateTierList(id: number, updates: Partial<TierList>): Promise<TierList | undefined>;
  deleteTierList(id: number): Promise<boolean>;

  // Todo methods
  getTodo(id: number): Promise<Todo | undefined>;
  getTodosByUserId(userId: number): Promise<Todo[]>;
  createTodo(todo: InsertTodo): Promise<Todo>;
  updateTodo(id: number, updates: Partial<Todo>): Promise<Todo | undefined>;
  deleteTodo(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tierLists: Map<number, TierList>;
  private todos: Map<number, Todo>;
  private currentUserId: number;
  private currentTierListId: number;
  private currentTodoId: number;

  constructor() {
    this.users = new Map();
    this.tierLists = new Map();
    this.todos = new Map();
    this.currentUserId = 1;
    this.currentTierListId = 1;
    this.currentTodoId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.googleId === googleId
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const createdAt = new Date().toISOString();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }

  // Tier list methods
  async getTierList(id: number): Promise<TierList | undefined> {
    return this.tierLists.get(id);
  }

  async getTierListsByUserId(userId: number): Promise<TierList[]> {
    return Array.from(this.tierLists.values()).filter(
      (tierList) => tierList.userId === userId
    );
  }

  async createTierList(insertTierList: InsertTierList): Promise<TierList> {
    const id = this.currentTierListId++;
    const createdAt = new Date().toISOString();
    const updatedAt = createdAt;
    const tierList: TierList = { ...insertTierList, id, createdAt, updatedAt };
    this.tierLists.set(id, tierList);
    return tierList;
  }

  async updateTierList(id: number, updates: Partial<TierList>): Promise<TierList | undefined> {
    const tierList = this.tierLists.get(id);
    if (!tierList) return undefined;

    const updatedTierList = { ...tierList, ...updates };
    this.tierLists.set(id, updatedTierList);
    return updatedTierList;
  }

  async deleteTierList(id: number): Promise<boolean> {
    return this.tierLists.delete(id);
  }

  // Todo methods
  async getTodo(id: number): Promise<Todo | undefined> {
    return this.todos.get(id);
  }

  async getTodosByUserId(userId: number): Promise<Todo[]> {
    return Array.from(this.todos.values()).filter(
      (todo) => todo.userId === userId
    );
  }

  async createTodo(insertTodo: InsertTodo): Promise<Todo> {
    const id = this.currentTodoId++;
    const createdAt = new Date().toISOString();
    const updatedAt = createdAt;
    const todo: Todo = { 
      ...insertTodo, 
      id, 
      createdAt,
      updatedAt,
      completed: false,
      status: "plan"
    };
    this.todos.set(id, todo);
    return todo;
  }

  async updateTodo(id: number, updates: Partial<Todo>): Promise<Todo | undefined> {
    const todo = this.todos.get(id);
    if (!todo) return undefined;

    const updatedTodo = { ...todo, ...updates };
    this.todos.set(id, updatedTodo);
    return updatedTodo;
  }

  async deleteTodo(id: number): Promise<boolean> {
    return this.todos.delete(id);
  }
}

export const storage = new MemStorage();
