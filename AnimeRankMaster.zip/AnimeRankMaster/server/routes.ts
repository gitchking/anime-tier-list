import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTierListSchema, insertTodoSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Google OAuth routes
  app.get("/api/auth/google", (req, res) => {
    const googleClientId = process.env.GOOGLE_CLIENT_ID;
    if (!googleClientId) {
      return res.status(500).json({ error: "Google OAuth not configured" });
    }
    
    const redirectUri = `${req.protocol}://${req.get('host')}/api/auth/google/callback`;
    const scope = 'email profile';
    const googleAuthUrl = `https://accounts.google.com/oauth2/authorize?client_id=${googleClientId}&redirect_uri=${redirectUri}&scope=${scope}&response_type=code`;
    
    res.redirect(googleAuthUrl);
  });

  app.get("/api/auth/google/callback", async (req, res) => {
    try {
      const { code } = req.query;
      if (!code) {
        return res.status(400).json({ error: "Authorization code missing" });
      }

      // Exchange code for access token
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client_id: process.env.GOOGLE_CLIENT_ID,
          client_secret: process.env.GOOGLE_CLIENT_SECRET,
          code,
          grant_type: 'authorization_code',
          redirect_uri: `${req.protocol}://${req.get('host')}/api/auth/google/callback`
        })
      });

      const tokenData = await tokenResponse.json();
      
      // Get user info from Google
      const userResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { Authorization: `Bearer ${tokenData.access_token}` }
      });
      
      const googleUser = await userResponse.json();
      
      // Check if user exists, create if not
      let user = await storage.getUserByGoogleId(googleUser.id);
      if (!user) {
        user = await storage.createUser({
          googleId: googleUser.id,
          email: googleUser.email,
          displayName: googleUser.name,
          photoURL: googleUser.picture
        });
      }

      // Store session and redirect to frontend with success
      res.redirect(`/?auth=success&token=${tokenData.access_token}&user=${encodeURIComponent(JSON.stringify(user))}`);
    } catch (error) {
      console.error('OAuth callback error:', error);
      res.redirect('/?auth=error');
    }
  });

  app.get("/api/auth/verify", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace('Bearer ', '');
      if (!token) {
        return res.status(401).json({ error: "No token provided" });
      }

      // Verify token with Google
      const response = await fetch(`https://www.googleapis.com/oauth2/v2/userinfo?access_token=${token}`);
      if (!response.ok) {
        return res.status(401).json({ error: "Invalid token" });
      }

      const googleUser = await response.json();
      const user = await storage.getUserByGoogleId(googleUser.id);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json(user);
    } catch (error) {
      res.status(401).json({ error: "Token verification failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    res.json({ success: true });
  });

  // User routes
  app.get("/api/users/:googleId", async (req, res) => {
    try {
      const { googleId } = req.params;
      const user = await storage.getUserByGoogleId(googleId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Tier list routes
  app.get("/api/tier-lists", async (req, res) => {
    try {
      const { userId } = req.query;
      
      if (!userId) {
        return res.status(400).json({ error: "User ID is required" });
      }
      
      const tierLists = await storage.getTierListsByUserId(Number(userId));
      res.json(tierLists);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/tier-lists", async (req, res) => {
    try {
      console.log("Raw request body:", JSON.stringify(req.body, null, 2));
      
      // Extract data directly without strict validation
      const tierListData = {
        userId: req.body.userId || "anonymous-user",
        title: req.body.title || "My Tier List",
        data: req.body
      };
      
      console.log("Creating tier list with data:", tierListData);
      
      const tierList = await storage.createTierList(tierListData);
      console.log("Successfully created tier list:", tierList);
      res.json(tierList);
    } catch (error) {
      console.error("Full error details:", error);
      res.status(500).json({ error: "Failed to save tier list", details: error.message });
    }
  });

  app.get("/api/tier-lists/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const tierList = await storage.getTierList(Number(id));
      
      if (!tierList) {
        return res.status(404).json({ error: "Tier list not found" });
      }
      
      res.json(tierList);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/tier-lists/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const tierList = await storage.updateTierList(Number(id), updates);
      
      if (!tierList) {
        return res.status(404).json({ error: "Tier list not found" });
      }
      
      res.json(tierList);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/tier-lists/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteTierList(Number(id));
      
      if (!success) {
        return res.status(404).json({ error: "Tier list not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Todo routes
  app.get("/api/todos", async (req, res) => {
    try {
      const { userId } = req.query;
      
      if (!userId) {
        return res.status(400).json({ error: "User ID is required" });
      }
      
      const todos = await storage.getTodosByUserId(Number(userId));
      res.json(todos);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/todos", async (req, res) => {
    try {
      const todoData = insertTodoSchema.parse(req.body);
      const todo = await storage.createTodo(todoData);
      res.json(todo);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/todos/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const todo = await storage.getTodo(Number(id));
      
      if (!todo) {
        return res.status(404).json({ error: "Todo not found" });
      }
      
      res.json(todo);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/todos/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const todo = await storage.updateTodo(Number(id), updates);
      
      if (!todo) {
        return res.status(404).json({ error: "Todo not found" });
      }
      
      res.json(todo);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/todos/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteTodo(Number(id));
      
      if (!success) {
        return res.status(404).json({ error: "Todo not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
