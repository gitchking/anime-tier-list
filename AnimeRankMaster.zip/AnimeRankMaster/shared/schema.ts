import { z } from "zod";

export const userSchema = z.object({
  id: z.number(),
  googleId: z.string(),
  email: z.string().email(),
  displayName: z.string().optional(),
  photoURL: z.string().optional(),
  createdAt: z.string(),
});

export const tierListSchema = z.object({
  id: z.number(),
  userId: z.number(),
  title: z.string(),
  data: z.any(),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export const todoSchema = z.object({
  id: z.number(),
  userId: z.number(),
  title: z.string(),
  description: z.string().optional(),
  completed: z.boolean().default(false),
  status: z.enum(["watching", "plan", "completed"]).default("plan"),
  createdAt: z.string(),
  updatedAt: z.string(),
});

// Insert schemas (omit auto-generated fields)
export const insertUserSchema = userSchema.omit({
  id: true,
  createdAt: true,
});

export const insertTierListSchema = z.object({
  userId: z.number(),
  title: z.string(),
  data: z.any(),
});

export const insertTodoSchema = todoSchema.omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Type exports
export type User = z.infer<typeof userSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type TierList = z.infer<typeof tierListSchema>;
export type InsertTierList = z.infer<typeof insertTierListSchema>;
export type Todo = z.infer<typeof todoSchema>;
export type InsertTodo = z.infer<typeof insertTodoSchema>;
