import { signInWithGoogle as firebaseSignInWithGoogle, signOut as firebaseSignOut, onAuthStateChange as firebaseOnAuthStateChange } from './firebase';
import { User } from 'firebase/auth';

// Export Firebase auth functions directly
export const signInWithGoogle = firebaseSignInWithGoogle;
export const signOut = firebaseSignOut;
export const onAuthStateChange = firebaseOnAuthStateChange;

export function getCurrentUser() {
  return null; // Will be handled by Firebase auth state
}

export function isAuthenticated() {
  return false; // Will be handled by Firebase auth state
}

export function handleRedirect() {
  return Promise.resolve(null);
}