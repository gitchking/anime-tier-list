import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "../lib/queryClient";
import { useToast } from "../hooks/use-toast";
import { onAuthStateChange } from "../lib/auth";
import { User } from "firebase/auth";

interface Todo {
  id: number;
  title: string;
  description?: string;
  completed: boolean;
  status: "watching" | "plan" | "completed";
  createdAt: string;
}

export default function TodoList() {
  const [user, setUser] = useState<User | null>(null);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskDescription, setNewTaskDescription] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    const unsubscribe = onAuthStateChange((user) => {
      setUser(user);
    });
    return unsubscribe;
  }, []);

  const { data: todos = [], isLoading } = useQuery({
    queryKey: ["/api/todos"],
    queryFn: () => fetch(`/api/todos?userId=1`).then(res => res.json()),
    enabled: true, // Allow todos to work without authentication
  });

  const addTodoMutation = useMutation({
    mutationFn: async (data: { title: string; description?: string }) => {
      const todoData = {
        ...data,
        userId: 1 // Using a default user ID since authentication is optional
      };
      const response = await apiRequest("POST", "/api/todos", todoData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
      setNewTaskTitle("");
      setNewTaskDescription("");
      toast({
        title: "Success",
        description: "Task added successfully!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateTodoMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Todo> }) => {
      const response = await apiRequest("PATCH", `/api/todos/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteTodoMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/todos/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
      toast({
        title: "Success",
        description: "Task deleted successfully!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAddTask = () => {
    if (!newTaskTitle.trim()) return;
    
    addTodoMutation.mutate({
      title: newTaskTitle,
      description: newTaskDescription || undefined,
    });
  };

  const handleToggleComplete = (todo: Todo) => {
    const newStatus = todo.completed ? "plan" : "completed";
    updateTodoMutation.mutate({
      id: todo.id,
      data: {
        completed: !todo.completed,
        status: newStatus,
      },
    });
  };

  const handleDeleteTask = (id: number) => {
    deleteTodoMutation.mutate(id);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleAddTask();
    }
  };

  const watchingCount = todos.filter((todo: Todo) => todo.status === "watching").length;
  const planCount = todos.filter((todo: Todo) => todo.status === "plan").length;
  const completedCount = todos.filter((todo: Todo) => todo.status === "completed").length;

  if (!user) {
    return (
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <div className="text-center">
            <h2 className="text-4xl font-poppins font-bold text-nature-700 dark:text-night-200 mb-4">Anime Tasks</h2>
            <p className="text-lg text-nature-600 dark:text-night-300">Please sign in to manage your anime tasks</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-4 mb-6">
            <div className="animate-leaf-sway dark:animate-star-pulse">
              <i className="fas fa-leaf text-4xl text-nature-400 dark:hidden"></i>
              <i className="fas fa-star text-4xl text-night-300 hidden dark:block"></i>
            </div>
            <h2 className="text-4xl font-poppins font-bold text-nature-700 dark:text-night-200">Anime Tasks</h2>
            <div className="animate-leaf-sway dark:animate-star-pulse">
              <i className="fas fa-leaf text-4xl text-nature-400 dark:hidden"></i>
              <i className="fas fa-star text-4xl text-night-300 hidden dark:block"></i>
            </div>
          </div>
          <p className="text-lg text-nature-600 dark:text-night-300">Keep track of your anime watching list and goals</p>
        </div>

        {/* Add Task Form */}
        <div className="bg-white/60 dark:bg-transparent backdrop-blur-sm rounded-2xl p-6 border border-nature-200 dark:border-night-700 mb-8">
          <div className="space-y-4">
            <div className="flex gap-4">
              <input
                type="text"
                placeholder="Add new anime to watch..."
                value={newTaskTitle}
                onChange={(e) => setNewTaskTitle(e.target.value)}
                onKeyPress={handleKeyPress}
                className="flex-1 px-4 py-3 bg-white dark:bg-night-700 border border-nature-300 dark:border-night-600 rounded-lg focus:ring-2 focus:ring-nature-400 dark:focus:ring-night-400 focus:border-transparent text-nature-700 dark:text-night-200 placeholder-nature-500 dark:placeholder-night-400"
              />
              <button
                onClick={handleAddTask}
                disabled={addTodoMutation.isPending}
                className="bg-nature-500 dark:bg-night-500 text-white px-6 py-3 rounded-lg hover:bg-nature-600 dark:hover:bg-night-600 transition-colors duration-200 font-medium disabled:opacity-50"
              >
                <i className="fas fa-plus mr-2"></i>
                {addTodoMutation.isPending ? "Adding..." : "Add"}
              </button>
            </div>
            <input
              type="text"
              placeholder="Description (optional)..."
              value={newTaskDescription}
              onChange={(e) => setNewTaskDescription(e.target.value)}
              onKeyPress={handleKeyPress}
              className="w-full px-4 py-2 bg-white dark:bg-night-700 border border-nature-300 dark:border-night-600 rounded-lg focus:ring-2 focus:ring-nature-400 dark:focus:ring-night-400 focus:border-transparent text-nature-700 dark:text-night-200 placeholder-nature-500 dark:placeholder-night-400"
            />
          </div>
        </div>

        {/* Task Categories */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-red-50 dark:bg-red-900/20 rounded-xl p-4 border border-red-200 dark:border-red-800">
            <h3 className="font-poppins font-semibold text-red-700 dark:text-red-300 mb-2">
              <i className="fas fa-play mr-2"></i>Watching
            </h3>
            <p className="text-sm text-red-600 dark:text-red-400">Currently watching: <span className="font-bold">{watchingCount}</span></p>
          </div>
          <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-xl p-4 border border-yellow-200 dark:border-yellow-800">
            <h3 className="font-poppins font-semibold text-yellow-700 dark:text-yellow-300 mb-2">
              <i className="fas fa-clock mr-2"></i>Plan to Watch
            </h3>
            <p className="text-sm text-yellow-600 dark:text-yellow-400">In queue: <span className="font-bold">{planCount}</span></p>
          </div>
          <div className="bg-green-50 dark:bg-green-900/20 rounded-xl p-4 border border-green-200 dark:border-green-800">
            <h3 className="font-poppins font-semibold text-green-700 dark:text-green-300 mb-2">
              <i className="fas fa-check mr-2"></i>Completed
            </h3>
            <p className="text-sm text-green-600 dark:text-green-400">Finished: <span className="font-bold">{completedCount}</span></p>
          </div>
        </div>

        {/* Task List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-nature-500 dark:border-night-400 mx-auto"></div>
              <p className="mt-2 text-nature-600 dark:text-night-300">Loading tasks...</p>
            </div>
          ) : todos.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-nature-600 dark:text-night-300">No tasks yet. Add your first anime to get started!</p>
            </div>
          ) : (
            todos.map((todo: Todo) => (
              <div
                key={todo.id}
                className={`task-item bg-white/60 dark:bg-transparent backdrop-blur-sm rounded-xl p-4 border border-nature-200 dark:border-night-700 flex items-center gap-4 hover:shadow-lg transition-all duration-200 ${
                  todo.completed ? "opacity-75" : ""
                }`}
              >
                <input
                  type="checkbox"
                  checked={todo.completed}
                  onChange={() => handleToggleComplete(todo)}
                  className="w-5 h-5 text-nature-500 dark:text-night-500 rounded focus:ring-nature-400 dark:focus:ring-night-400"
                />
                <div className="flex-1">
                  <h4 className={`font-medium text-nature-700 dark:text-night-200 ${todo.completed ? "line-through" : ""}`}>
                    {todo.title}
                  </h4>
                  {todo.description && (
                    <p className="text-sm text-nature-500 dark:text-night-400">{todo.description}</p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    todo.status === "watching"
                      ? "bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400"
                      : todo.status === "plan"
                      ? "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-600 dark:text-yellow-400"
                      : "bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400"
                  }`}>
                    {todo.status === "watching" ? "Watching" : todo.status === "plan" ? "Plan to Watch" : "Completed"}
                  </span>
                  <button
                    onClick={() => handleDeleteTask(todo.id)}
                    className="text-nature-500 dark:text-night-400 hover:text-red-500 dark:hover:text-red-400 transition-colors duration-200"
                  >
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
}
