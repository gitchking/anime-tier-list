import { useState } from "react";
import Demo from "./Demo";

interface HomePageProps {
  onNavigateToBuilder: () => void;
}

export default function HomePage({ onNavigateToBuilder }: HomePageProps) {
  const [isDemoOpen, setIsDemoOpen] = useState(false);
  return (
    <section className="pt-20 pb-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          {/* Hero Content */}
          <div className="mb-12">
            <div className="inline-flex items-center space-x-4 mb-6">
              <div className="animate-float">
                <i className="fas fa-layer-group text-6xl text-nature-500 dark:text-night-400"></i>
              </div>
              <div className="animate-leaf-sway dark:animate-star-pulse">
                <i className="fas fa-leaf text-4xl text-nature-400 dark:hidden"></i>
                <i className="fas fa-star text-4xl text-night-300 hidden dark:block"></i>
              </div>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-poppins font-bold text-nature-700 dark:text-night-200 mb-6 leading-tight">
              Anime <span className="text-nature-500 dark:text-night-400">Tier</span> Lists
            </h1>
            
            <p className="text-xl md:text-2xl text-nature-600 dark:text-night-300 mb-8 font-light">
              Create, customize, and share your ultimate anime character rankings
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <button
                onClick={onNavigateToBuilder}
                className="bg-nature-500 dark:bg-night-500 text-white px-8 py-4 rounded-xl hover:bg-nature-600 dark:hover:bg-night-600 transition-all duration-200 font-medium text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                <i className="fas fa-plus mr-2"></i>Start Building
              </button>
              <button 
                onClick={() => setIsDemoOpen(true)}
                className="border-2 border-nature-500 dark:border-[#927bf9] text-nature-600 dark:text-night-400 px-8 py-4 rounded-xl hover:bg-nature-500 dark:hover:bg-night-500 hover:text-white transition-all duration-200 font-medium text-lg">
                <i className="fas fa-play mr-2"></i>View Demo
              </button>
            </div>
          </div>

          {/* Feature Cards */}
          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="bg-white/60 dark:bg-transparent backdrop-blur-sm rounded-2xl p-6 border border-nature-200 dark:border-night-700 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="w-16 h-16 bg-nature-100 dark:bg-night-700 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <i className="fas fa-arrows-alt text-2xl text-nature-500 dark:text-night-400"></i>
              </div>
              <h3 className="text-xl font-poppins font-semibold text-nature-700 dark:text-night-200 mb-3">Drag & Drop</h3>
              <p className="text-nature-600 dark:text-night-300">Intuitive interface for organizing your favorite characters with smooth animations</p>
            </div>

            <div className="bg-white/60 dark:bg-transparent backdrop-blur-sm rounded-2xl p-6 border border-nature-200 dark:border-night-700 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="w-16 h-16 bg-nature-100 dark:bg-night-700 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <i className="fas fa-palette text-2xl text-nature-500 dark:text-night-400"></i>
              </div>
              <h3 className="text-xl font-poppins font-semibold text-nature-700 dark:text-night-200 mb-3">Customizable</h3>
              <p className="text-nature-600 dark:text-night-300">Personalize tier colors, labels, and rankings to match your unique style</p>
            </div>

            <div className="bg-white/60 dark:bg-transparent backdrop-blur-sm rounded-2xl p-6 border border-nature-200 dark:border-night-700 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="w-16 h-16 bg-nature-100 dark:bg-night-700 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <i className="fas fa-share-alt text-2xl text-nature-500 dark:text-night-400"></i>
              </div>
              <h3 className="text-xl font-poppins font-semibold text-nature-700 dark:text-night-200 mb-3">Share & Save</h3>
              <p className="text-nature-600 dark:text-night-300">Save your tier lists and share them with the anime community</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Demo Component */}
      <Demo isOpen={isDemoOpen} onClose={() => setIsDemoOpen(false)} />
    </section>
  );
}
