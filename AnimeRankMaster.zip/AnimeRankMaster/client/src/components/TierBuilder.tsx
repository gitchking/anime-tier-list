import { useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "../lib/queryClient";
import { useToast } from "../hooks/use-toast";

interface Character {
  id: string;
  name: string;
  imageUrl: string;
}

interface TierRow {
  id: string;
  label: string;
  color: string;
  characters: Character[];
}

export default function TierBuilder() {
  const [tierRows, setTierRows] = useState<TierRow[]>([
    { id: "S", label: "S", color: "bg-red-500", characters: [] },
    { id: "A", label: "A", color: "bg-green-500", characters: [] },
    { id: "B", label: "B", color: "bg-blue-500", characters: [] },
    { id: "C", label: "C", color: "bg-yellow-500", characters: [] },
    { id: "D", label: "D", color: "bg-purple-500", characters: [] },
  ]);
  
  const [characterPool, setCharacterPool] = useState<Character[]>([]);
  const [draggedCharacter, setDraggedCharacter] = useState<Character | null>(null);
  const [tierListTitle, setTierListTitle] = useState("My Anime Tier List");
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const atlFileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveTierListMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/tier-lists", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Tier list saved successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tier-lists"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const uploadToMoebox = async (file: File): Promise<string> => {
    // First, always try base64 storage for reliability
    try {
      return new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.readAsDataURL(file);
      });
    } catch (error) {
      throw new Error('Failed to process image file');
    }
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    const uploadPromises = Array.from(files).map(async (file) => {
      if (file.type.startsWith("image/")) {
        try {
          const imageUrl = await uploadToMoebox(file);
          const newCharacter: Character = {
            id: Math.random().toString(36).substr(2, 9),
            name: file.name.replace(/\.[^/.]+$/, ""),
            imageUrl,
          };
          setCharacterPool((prev) => [...prev, newCharacter]);
        } catch (error) {
          toast({
            title: "Upload Error",
            description: `Failed to upload ${file.name}`,
            variant: "destructive",
          });
        }
      }
    });

    await Promise.all(uploadPromises);
    toast({
      title: "Success",
      description: "Images uploaded successfully!",
    });
  };

  const handleDragStart = (character: Character) => {
    setDraggedCharacter(character);
  };

  const handleDragEnd = () => {
    setDraggedCharacter(null);
  };

  const handleDrop = (tierRowId: string) => {
    if (!draggedCharacter) return;

    // Remove character from its current location
    setTierRows((prev) =>
      prev.map((row) => ({
        ...row,
        characters: row.characters.filter((char) => char.id !== draggedCharacter.id),
      }))
    );
    setCharacterPool((prev) =>
      prev.filter((char) => char.id !== draggedCharacter.id)
    );

    // Add character to the target tier row
    setTierRows((prev) =>
      prev.map((row) =>
        row.id === tierRowId
          ? { ...row, characters: [...row.characters, draggedCharacter] }
          : row
      )
    );
  };

  const handleDropToPool = () => {
    if (!draggedCharacter) return;

    // Remove character from tier rows
    setTierRows((prev) =>
      prev.map((row) => ({
        ...row,
        characters: row.characters.filter((char) => char.id !== draggedCharacter.id),
      }))
    );

    // Add character back to pool if not already there
    if (!characterPool.find((char) => char.id === draggedCharacter.id)) {
      setCharacterPool((prev) => [...prev, draggedCharacter]);
    }
  };

  const saveTierList = () => {
    const tierListData = {
      title: tierListTitle,
      data: {
        tiers: tierRows,
        characters: characterPool,
      },
    };
    saveTierListMutation.mutate(tierListData);
  };

  const downloadAsATL = () => {
    const atlData = {
      version: "1.0",
      title: tierListTitle,
      createdAt: new Date().toISOString(),
      tiers: tierRows.map(tier => ({
        id: tier.id,
        label: tier.label,
        color: tier.color,
        characters: tier.characters.map(char => ({
          id: char.id,
          name: char.name,
          imageUrl: char.imageUrl
        }))
      })),
      characterPool: characterPool.map(char => ({
        id: char.id,
        name: char.name,
        imageUrl: char.imageUrl
      }))
    };

    const dataStr = JSON.stringify(atlData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${tierListTitle.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.atl`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "Success",
      description: "Tier list downloaded as .atl file!",
    });
  };

  const handleATLRestore = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const atlData = JSON.parse(e.target?.result as string);
        
        // Validate ATL file structure
        if (!atlData.version || !atlData.title || !atlData.tiers) {
          throw new Error('Invalid ATL file format');
        }

        // Restore tier list data
        setTierListTitle(atlData.title);
        setTierRows(atlData.tiers.map((tier: any) => ({
          id: tier.id,
          label: tier.label,
          color: tier.color,
          characters: tier.characters || []
        })));
        setCharacterPool(atlData.characterPool || []);

        toast({
          title: "Success",
          description: "Tier list restored from ATL file!",
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to restore ATL file. Please check the file format.",
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);
  };

  const resetTierList = () => {
    const allCharacters = [
      ...characterPool,
      ...tierRows.flatMap((row) => row.characters),
    ];
    setCharacterPool(allCharacters);
    setTierRows((prev) =>
      prev.map((row) => ({ ...row, characters: [] }))
    );
  };

  return (
    <section className="py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between mb-6">
            <div>
              <h2 className="text-3xl font-poppins font-bold text-nature-700 dark:text-night-200 mb-2">Tier List Builder</h2>
              <input
                type="text"
                value={tierListTitle}
                onChange={(e) => setTierListTitle(e.target.value)}
                className="text-lg bg-transparent border-b border-nature-300 dark:border-night-600 focus:border-nature-500 dark:focus:border-night-400 outline-none text-nature-600 dark:text-night-300"
              />
            </div>
            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="bg-nature-500 dark:bg-night-500 text-white px-4 py-2 rounded-lg hover:bg-nature-600 dark:hover:bg-night-600 transition-colors duration-200"
              >
                <i className="fas fa-upload mr-2"></i>Upload Images
              </button>
              <button
                onClick={() => atlFileInputRef.current?.click()}
                className="bg-white dark:bg-night-800 text-nature-600 dark:text-night-300 px-4 py-2 rounded-lg border border-nature-300 dark:border-night-600 hover:bg-nature-50 dark:hover:bg-night-700 transition-colors duration-200"
              >
                <i className="fas fa-file-import mr-2"></i>Restore .ATL
              </button>

              <button
                onClick={downloadAsATL}
                className="bg-white dark:bg-night-800 text-nature-600 dark:text-night-300 px-4 py-2 rounded-lg border border-nature-300 dark:border-night-600 hover:bg-nature-50 dark:hover:bg-night-700 transition-colors duration-200"
              >
                <i className="fas fa-download mr-2"></i>Download .ATL
              </button>
              <button
                onClick={resetTierList}
                className="bg-white dark:bg-night-800 text-nature-600 dark:text-night-300 px-4 py-2 rounded-lg border border-nature-300 dark:border-night-600 hover:bg-nature-50 dark:hover:bg-night-700 transition-colors duration-200"
              >
                <i className="fas fa-undo mr-2"></i>Reset
              </button>
            </div>
          </div>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*"
          onChange={handleImageUpload}
          className="hidden"
        />
        
        <input
          ref={atlFileInputRef}
          type="file"
          accept=".atl,.json"
          onChange={handleATLRestore}
          className="hidden"
        />

        {/* Tier Rows */}
        <div className="space-y-4 mb-8">
          {tierRows.map((row) => (
            <div key={row.id} className="tier-row">
              <div className="flex">
                <div className={`w-24 ${row.color} text-white flex items-center justify-center font-bold text-2xl font-poppins rounded-l-lg`}>
                  {row.label}
                </div>
                <div
                  className="flex-1 bg-white/60 dark:bg-transparent backdrop-blur-sm border-2 border-solid border-nature-300 dark:border-night-600 rounded-r-lg min-h-24 p-4 flex items-center gap-4 transition-all duration-300 hover:border-nature-400 dark:hover:border-blue-400"
                  onDragOver={(e) => {
                    e.preventDefault();
                    const isDark = document.documentElement.classList.contains('dark');
                    if (isDark) {
                      e.currentTarget.style.borderColor = '#60a5fa'; // blue-400
                      e.currentTarget.style.backgroundColor = 'rgba(96, 165, 250, 0.1)';
                    } else {
                      e.currentTarget.style.borderColor = 'hsl(var(--nature-500))';
                      e.currentTarget.style.backgroundColor = 'rgba(167, 201, 87, 0.1)';
                    }
                  }}
                  onDragLeave={(e) => {
                    e.currentTarget.style.borderColor = '';
                    e.currentTarget.style.backgroundColor = '';
                  }}
                  onDrop={(e) => {
                    e.currentTarget.style.borderColor = '';
                    e.currentTarget.style.backgroundColor = '';
                    handleDrop(row.id);
                  }}
                >
                  {row.characters.length === 0 ? (
                    <span className="text-nature-500 dark:text-night-400 font-medium">Drop characters here...</span>
                  ) : (
                    row.characters.map((character) => (
                      <div
                        key={character.id}
                        className="character-item w-20 h-20 bg-gray-200 dark:bg-night-700 rounded-lg cursor-move hover:shadow-xl hover:scale-105 transition-all duration-300 ease-out flex items-center justify-center overflow-hidden transform hover:-translate-y-1"
                        draggable
                        onDragStart={(e) => {
                          handleDragStart(character);
                          e.currentTarget.style.opacity = '0.5';
                        }}
                        onDragEnd={(e) => {
                          handleDragEnd();
                          e.currentTarget.style.opacity = '1';
                        }}
                      >
                        <img
                          src={character.imageUrl}
                          alt={character.name}
                          className="w-full h-full object-cover rounded-lg"
                          title={character.name}
                        />
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Character Pool */}
        <div className="bg-white/60 dark:bg-transparent backdrop-blur-sm rounded-2xl p-6 border border-nature-200 dark:border-night-700">
          <h3 className="text-xl font-poppins font-semibold text-nature-700 dark:text-night-200 mb-4">Character Pool</h3>
          <div
            className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-12 gap-4 min-h-32"
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDropToPool}
          >
            {characterPool.length === 0 ? (
              <div className="col-span-full flex items-center justify-center text-nature-500 dark:text-night-400 font-medium">
                Upload images to start building your tier list
              </div>
            ) : (
              characterPool.map((character) => (
                <div
                  key={character.id}
                  className="character-item w-20 h-20 bg-gray-200 dark:bg-night-700 rounded-lg cursor-move hover:shadow-xl hover:scale-105 transition-all duration-300 ease-out flex items-center justify-center overflow-hidden transform hover:-translate-y-1"
                  draggable
                  onDragStart={(e) => {
                    handleDragStart(character);
                    e.currentTarget.style.opacity = '0.5';
                  }}
                  onDragEnd={(e) => {
                    handleDragEnd();
                    e.currentTarget.style.opacity = '1';
                  }}
                >
                  <img
                    src={character.imageUrl}
                    alt={character.name}
                    className="w-full h-full object-cover rounded-lg"
                    title={character.name}
                  />
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
