import { useState, useEffect } from "react";
import { useTheme } from "./ThemeProvider";
import { signInWithGoogle, signOut, onAuthStateChange } from "../lib/auth";
import { User } from "firebase/auth";

interface HeaderProps {
  currentSection: string;
  onSectionChange: (section: string) => void;
}

export default function Header({ currentSection, onSectionChange }: HeaderProps) {
  const { theme, toggleTheme } = useTheme();
  const [user, setUser] = useState<User | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChange((user) => {
      setUser(user);
    });
    
    return unsubscribe;
  }, []);

  const handleSignIn = async () => {
    try {
      await signInWithGoogle();
    } catch (error) {
      console.error('Sign-in error:', error);
    }
  };

  const handleSignOut = () => {
    signOut();
  };

  return (
    <header className="sticky top-0 z-50 bg-white/80 dark:bg-transparent backdrop-blur-md border-b border-nature-200 dark:border-transparent transition-all duration-300">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-green-400 via-green-500 to-green-600 dark:from-blue-400 dark:via-blue-500 dark:to-blue-600 rounded-xl flex items-center justify-center shadow-lg animate-gradient-shift">
              <div className="animate-tier-pulse">
                <i className="fas fa-list text-black dark:text-white text-lg transition-colors duration-300"></i>
              </div>
            </div>
            <h1 className="text-xl font-poppins font-bold text-nature-600 dark:text-night-300">AnimeTier</h1>
          </div>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center space-x-6">
            <button
              onClick={() => onSectionChange("home")}
              className={`nav-link font-medium transition-colors duration-200 ${
                currentSection === "home"
                  ? "text-nature-500 dark:text-night-400"
                  : "text-nature-600 dark:text-night-300 hover:text-nature-500 dark:hover:text-night-400"
              }`}
            >
              Home
            </button>
            <button
              onClick={() => onSectionChange("builder")}
              className={`nav-link font-medium transition-colors duration-200 ${
                currentSection === "builder"
                  ? "text-nature-500 dark:text-night-400"
                  : "text-nature-600 dark:text-night-300 hover:text-nature-500 dark:hover:text-night-400"
              }`}
            >
              Builder
            </button>
            <button
              onClick={() => onSectionChange("todo")}
              className={`nav-link font-medium transition-colors duration-200 ${
                currentSection === "todo"
                  ? "text-nature-500 dark:text-night-400"
                  : "text-nature-600 dark:text-night-300 hover:text-nature-500 dark:hover:text-night-400"
              }`}
            >
              Tasks
            </button>
          </div>

          {/* Theme Toggle & Auth */}
          <div className="flex items-center space-x-4">
            <button
              onClick={toggleTheme}
              className="w-12 h-6 bg-nature-200 dark:bg-night-700 rounded-full relative transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-nature-400 dark:focus:ring-night-400"
            >
              <div className={`w-5 h-5 bg-white dark:bg-night-200 rounded-full shadow-md transform transition-transform duration-300 absolute top-0.5 ${theme === 'dark' ? 'translate-x-6' : 'translate-x-0.5'} flex items-center justify-center`}>
                <i className={`fas fa-leaf text-nature-500 text-xs ${theme === 'dark' ? 'hidden' : 'block'}`}></i>
                <i className={`fas fa-star text-night-400 text-xs animate-star-pulse ${theme === 'dark' ? 'block' : 'hidden'}`}></i>
              </div>
            </button>
            
            {user ? (
              <div className="flex items-center space-x-3">
                <img
                  src={user.photoURL || "/default-avatar.png"}
                  alt={user.displayName || "User"}
                  className="w-8 h-8 rounded-full"
                />
                <button
                  onClick={handleSignOut}
                  className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
                  title="Sign Out"
                >
                  <svg
                    className="w-5 h-5 text-gray-600 dark:text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                    />
                  </svg>
                </button>
              </div>
            ) : (
              <button
                onClick={handleSignIn}
                className="bg-nature-500 dark:bg-night-500 text-white px-4 py-2 rounded-lg hover:bg-nature-600 dark:hover:bg-night-600 transition-colors duration-200 font-medium"
              >
                <i className="fab fa-google mr-2"></i>Sign In
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden w-8 h-8 flex items-center justify-center"
          >
            <i className="fas fa-bars text-nature-600 dark:text-night-300"></i>
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-nature-200 dark:border-night-700">
            <div className="flex flex-col space-y-2">
              <button
                onClick={() => {onSectionChange("home"); setIsMenuOpen(false);}}
                className="text-left text-nature-600 dark:text-night-300 hover:text-nature-500 dark:hover:text-night-400 font-medium py-2"
              >
                Home
              </button>
              <button
                onClick={() => {onSectionChange("builder"); setIsMenuOpen(false);}}
                className="text-left text-nature-600 dark:text-night-300 hover:text-nature-500 dark:hover:text-night-400 font-medium py-2"
              >
                Builder
              </button>
              <button
                onClick={() => {onSectionChange("todo"); setIsMenuOpen(false);}}
                className="text-left text-nature-600 dark:text-night-300 hover:text-nature-500 dark:hover:text-night-400 font-medium py-2"
              >
                Tasks
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
