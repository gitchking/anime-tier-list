import { useState } from "react";

interface DemoStep {
  id: number;
  title: string;
  content: string;
  target?: string;
  position: 'top' | 'bottom' | 'left' | 'right';
}

const demoSteps: DemoStep[] = [
  {
    id: 1,
    title: "Welcome to AnimeTier! 🎌",
    content: "Create amazing anime character tier lists with our intuitive drag-and-drop interface!",
    position: 'bottom'
  },
  {
    id: 2,
    title: "Upload Your Characters 📸",
    content: "Click 'Upload Images' to add anime character pictures. Images are securely stored via catbox.moe!",
    position: 'bottom'
  },
  {
    id: 3,
    title: "Drag & Drop Magic ✨",
    content: "Simply drag characters from the pool into different tier rows (S, A, B, C, D) to rank them!",
    position: 'top'
  },
  {
    id: 4,
    title: "Save Your Work 💾",
    content: "Save your tier list to the cloud or download as .ATL file for backup and sharing!",
    position: 'bottom'
  },
  {
    id: 5,
    title: "Restore Tier Lists 🔄",
    content: "Use 'Restore .ATL' to load previously saved tier lists from your computer!",
    position: 'bottom'
  },
  {
    id: 6,
    title: "Anime Tasks 📝",
    content: "Track your watching progress with our beautiful task manager in the 'Tasks' tab!",
    position: 'bottom'
  },
  {
    id: 7,
    title: "Dark Mode Magic 🌙",
    content: "Toggle between nature-inspired light mode and beautiful night sky dark mode!",
    position: 'left'
  },
  {
    id: 8,
    title: "Ready to Start! 🚀",
    content: "You're all set! Start building your ultimate anime tier lists. Need help? Contact us at proxima720p@gmail.com",
    position: 'bottom'
  }
];

interface DemoProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Demo({ isOpen, onClose }: DemoProps) {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const step = demoSteps[currentStep];
  const isLastStep = currentStep === demoSteps.length - 1;
  const isFirstStep = currentStep === 0;

  const nextStep = () => {
    if (isLastStep) {
      onClose();
    } else {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (!isFirstStep) {
      setCurrentStep(currentStep - 1);
    }
  };

  const skipDemo = () => {
    onClose();
  };

  return (
    <>
      {/* Overlay */}
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 transition-all duration-300">
        
        {/* Demo Popup */}
        <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white/80 dark:bg-transparent backdrop-blur-md rounded-2xl p-8 border-2 border-nature-400 dark:border-blue-500 shadow-2xl max-w-md w-full mx-4 z-51">
          
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-green-400 via-green-500 to-green-600 dark:from-blue-400 dark:via-blue-500 dark:to-blue-600 rounded-lg flex items-center justify-center animate-gradient-shift">
                <div className="animate-tier-pulse">
                  <i className="fas fa-list text-black dark:text-white text-sm transition-colors duration-300"></i>
                </div>
              </div>
              <h3 className="text-lg font-poppins font-semibold text-nature-700 dark:text-night-200">
                Demo Tour
              </h3>
            </div>
            <button
              onClick={skipDemo}
              className="text-nature-500 dark:text-night-400 hover:text-nature-700 dark:hover:text-night-200 transition-colors"
            >
              <i className="fas fa-times"></i>
            </button>
          </div>

          {/* Step Counter */}
          <div className="flex items-center justify-center mb-6">
            <div className="flex space-x-2">
              {demoSteps.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentStep
                      ? 'bg-nature-500 dark:bg-night-400 w-6'
                      : index < currentStep
                      ? 'bg-nature-300 dark:bg-night-600'
                      : 'bg-gray-200 dark:bg-gray-700'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Content */}
          <div className="text-center mb-8">
            <h4 className="text-xl font-poppins font-bold text-nature-700 dark:text-night-200 mb-4">
              {step.title}
            </h4>
            <p className="text-nature-600 dark:text-night-300 leading-relaxed">
              {step.content}
            </p>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <button
              onClick={prevStep}
              disabled={isFirstStep}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                isFirstStep
                  ? 'text-gray-400 cursor-not-allowed'
                  : 'text-nature-600 dark:text-night-300 hover:bg-nature-50 dark:hover:bg-night-700'
              }`}
            >
              <i className="fas fa-arrow-left mr-2"></i>Previous
            </button>

            <span className="text-sm text-nature-500 dark:text-night-400">
              {currentStep + 1} of {demoSteps.length}
            </span>

            <button
              onClick={nextStep}
              className="bg-nature-500 dark:bg-night-500 text-white px-6 py-2 rounded-lg hover:bg-nature-600 dark:hover:bg-night-600 transition-colors font-medium"
            >
              {isLastStep ? (
                <>
                  <i className="fas fa-check mr-2"></i>Finish
                </>
              ) : (
                <>
                  Next<i className="fas fa-arrow-right ml-2"></i>
                </>
              )}
            </button>
          </div>

          {/* Skip Button */}
          <div className="text-center mt-4">
            <button
              onClick={skipDemo}
              className="text-sm text-nature-500 dark:text-night-400 hover:text-nature-700 dark:hover:text-night-200 transition-colors"
            >
              Skip Demo
            </button>
          </div>
        </div>
      </div>
    </>
  );
}