export default function Footer() {
  return (
    <footer className="bg-white/80 dark:bg-transparent backdrop-blur-md border-t border-nature-200 dark:border-transparent py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-green-400 via-green-500 to-green-600 dark:from-blue-400 dark:via-blue-500 dark:to-blue-600 rounded-lg flex items-center justify-center animate-gradient-shift">
              <i className="fas fa-list text-black dark:text-white text-sm transition-colors duration-300"></i>
            </div>
            <span className="text-nature-600 dark:text-night-300 font-medium">AnimeTier</span>
          </div>

          <div className="flex items-center space-x-6">
            <a href="/terms" className="text-nature-600 dark:text-night-400 hover:text-nature-500 dark:hover:text-night-300 transition-colors duration-200 text-sm">
              <i className="fas fa-file-contract mr-1"></i>Terms
            </a>
            <a href="/privacy" className="text-nature-600 dark:text-night-400 hover:text-nature-500 dark:hover:text-night-300 transition-colors duration-200 text-sm">
              <i className="fas fa-shield-alt mr-1"></i>Privacy
            </a>
            <a href="mailto:proxima720p@gmail.com" className="text-nature-600 dark:text-night-400 hover:text-nature-500 dark:hover:text-night-300 transition-colors duration-200 text-sm">
              <i className="fas fa-envelope mr-1"></i>Contact
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
