import { useState, useEffect } from "react";
import { ThemeProvider } from "../components/ThemeProvider";
import Header from "../components/Header";
import Footer from "../components/Footer";
import HomePage from "../components/HomePage";
import TierBuilder from "../components/TierBuilder";
import TodoList from "../components/TodoList";
import { handleRedirect } from "../lib/auth";

export default function Home() {
  const [currentSection, setCurrentSection] = useState("home");

  useEffect(() => {
    // Handle Firebase redirect result
    handleRedirect().catch((error) => {
      console.error("Firebase redirect error:", error);
    });
  }, []);

  const renderCurrentSection = () => {
    switch (currentSection) {
      case "builder":
        return <TierBuilder />;
      case "todo":
        return <TodoList />;
      default:
        return <HomePage onNavigateToBuilder={() => setCurrentSection("builder")} />;
    }
  };

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-gradient-to-br from-white to-nature-50 dark:from-night-900 dark:to-night-800 nature-pattern dark:stars-bg transition-all duration-500">
        <Header currentSection={currentSection} onSectionChange={setCurrentSection} />
        <main>
          {renderCurrentSection()}
        </main>
        <Footer />
      </div>
    </ThemeProvider>
  );
}
