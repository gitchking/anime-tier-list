import { useLocation } from "wouter";
import { ThemeProvider } from "../components/ThemeProvider";
import Header from "../components/Header";
import Footer from "../components/Footer";

export default function Privacy() {
  const [, setLocation] = useLocation();

  const handleSectionChange = (section: string) => {
    if (section === "home") {
      setLocation("/");
    } else if (section === "builder" || section === "todo") {
      setLocation("/#" + section);
    }
  };

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-gradient-to-br from-white to-nature-50 dark:from-night-900 dark:to-night-800 nature-pattern dark:stars-bg transition-all duration-500">
        <Header currentSection="privacy" onSectionChange={handleSectionChange} />
        <main className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
            <div className="bg-white/60 dark:bg-transparent backdrop-blur-sm rounded-2xl p-8 border border-nature-200 dark:border-night-700">
              <div className="text-center mb-8">
                <h1 className="text-4xl font-poppins font-bold text-nature-700 dark:text-night-200 mb-4">Privacy Policy</h1>
                <p className="text-lg text-nature-600 dark:text-night-300">Last updated: {new Date().toLocaleDateString()}</p>
              </div>

              <div className="space-y-6 text-nature-700 dark:text-night-300">
                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">1. Information We Collect</h2>
                  <p>When you use AnimeTier, we may collect the following information:</p>
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>Google account information (name, email, profile picture) when you sign in</li>
                    <li>Tier lists and anime tasks you create</li>
                    <li>Images you upload for your tier lists</li>
                    <li>Usage data and analytics to improve our service</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">2. How We Use Your Information</h2>
                  <p>We use the collected information to:</p>
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>Provide and maintain our service</li>
                    <li>Save your tier lists and anime tasks</li>
                    <li>Authenticate your account through Google Sign-In</li>
                    <li>Improve user experience and service functionality</li>
                    <li>Communicate with you about service updates</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">3. Information Sharing</h2>
                  <p>We do not sell, trade, or rent your personal information to third parties. We may share your information only in the following circumstances:</p>
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>With your explicit consent</li>
                    <li>To comply with legal obligations</li>
                    <li>To protect our rights and safety</li>
                    <li>In connection with a business transfer or merger</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">4. Data Storage and Security</h2>
                  <p>We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. Your data is stored securely and we use industry-standard encryption protocols.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">5. Third-Party Services</h2>
                  <p>Our service uses the following third-party services:</p>
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li><strong>Google Firebase:</strong> For user authentication and account management</li>
                    <li><strong>Catbox.moe:</strong> For secure image hosting and storage</li>
                  </ul>
                  <p className="mt-2">These services have their own privacy policies, which we encourage you to review.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">6. Cookies and Local Storage</h2>
                  <p>We use local storage to save your theme preferences and improve your user experience. We do not use tracking cookies for advertising purposes.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">7. Your Rights</h2>
                  <p>You have the right to:</p>
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>Access your personal data</li>
                    <li>Correct inaccurate information</li>
                    <li>Delete your account and associated data</li>
                    <li>Export your tier lists and data</li>
                    <li>Withdraw consent for data processing</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">8. Children's Privacy</h2>
                  <p>Our service is not directed to children under 13. We do not knowingly collect personal information from children under 13. If you become aware that a child has provided us with personal information, please contact us.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">9. Changes to Privacy Policy</h2>
                  <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">10. Contact Us</h2>
                  <p>If you have any questions about this Privacy Policy or our data practices, please contact us through our website. We are committed to resolving any privacy concerns you may have.</p>
                </section>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    </ThemeProvider>
  );
}