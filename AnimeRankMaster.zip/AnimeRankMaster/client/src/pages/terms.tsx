import { useLocation } from "wouter";
import { ThemeProvider } from "../components/ThemeProvider";
import Header from "../components/Header";
import Footer from "../components/Footer";

export default function Terms() {
  const [, setLocation] = useLocation();

  const handleSectionChange = (section: string) => {
    if (section === "home") {
      setLocation("/");
    } else if (section === "builder" || section === "todo") {
      setLocation("/#" + section);
    }
  };

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-gradient-to-br from-white to-nature-50 dark:from-night-900 dark:to-night-800 nature-pattern dark:stars-bg transition-all duration-500">
        <Header currentSection="terms" onSectionChange={handleSectionChange} />
        <main className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
            <div className="bg-white/60 dark:bg-transparent backdrop-blur-sm rounded-2xl p-8 border border-nature-200 dark:border-night-700">
              <div className="text-center mb-8">
                <h1 className="text-4xl font-poppins font-bold text-nature-700 dark:text-night-200 mb-4">Terms of Service</h1>
                <p className="text-lg text-nature-600 dark:text-night-300">Last updated: {new Date().toLocaleDateString()}</p>
              </div>

              <div className="space-y-6 text-nature-700 dark:text-night-300">
                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">1. Acceptance of Terms</h2>
                  <p>By accessing and using AnimeTier, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by these terms, please do not use this service.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">2. Description of Service</h2>
                  <p>AnimeTier is a web-based platform that allows users to create, customize, and share anime character tier lists. Users can upload images, organize characters into tiers, and manage their anime watching lists.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">3. User Accounts</h2>
                  <p>To access certain features of our service, you may be required to create an account using Google Sign-In. You are responsible for maintaining the confidentiality of your account and for all activities that occur under your account.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">4. User Content</h2>
                  <p>You retain ownership of any content you upload to AnimeTier. However, by uploading content, you grant us a non-exclusive, worldwide, royalty-free license to use, display, and distribute your content in connection with the service.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">5. Prohibited Uses</h2>
                  <ul className="list-disc list-inside space-y-2">
                    <li>Upload content that violates copyright or intellectual property rights</li>
                    <li>Use the service for any illegal or unauthorized purpose</li>
                    <li>Attempt to gain unauthorized access to the service or its systems</li>
                    <li>Upload malicious software or harmful content</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">6. Intellectual Property</h2>
                  <p>The service and its original content, features, and functionality are owned by AnimeTier and are protected by international copyright, trademark, patent, trade secret, and other intellectual property laws.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">7. Disclaimer</h2>
                  <p>The information on this service is provided on an "as is" basis. AnimeTier makes no warranties, expressed or implied, and hereby disclaims all other warranties including, without limitation, implied warranties of merchantability, fitness for a particular purpose, or non-infringement.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">8. Limitation of Liability</h2>
                  <p>In no event shall AnimeTier be liable for any direct, indirect, incidental, special, or consequential damages arising out of or in any way connected with the use of this service.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">9. Changes to Terms</h2>
                  <p>We reserve the right to modify these terms at any time. We will notify users of any changes by posting the new terms on this page. Your continued use of the service after such modifications constitutes acceptance of the updated terms.</p>
                </section>

                <section>
                  <h2 className="text-2xl font-poppins font-semibold text-nature-600 dark:text-night-200 mb-3">10. Contact Information</h2>
                  <p>If you have any questions about these Terms of Service, please contact us through our website.</p>
                </section>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    </ThemeProvider>
  );
}